#include<stdio.h>

int main (void)
{
    int x;
    printf("x: ");
    scanf("%i",&x);
    printf("x: %i\n", x);
}