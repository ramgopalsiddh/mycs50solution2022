-- write a SQL query to list the names of all songs in the database.


SELECT name FROM songs;