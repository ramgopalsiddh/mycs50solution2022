-- write a SQL query that returns the average energy of all the songs

SELECT AVG(energy) FROM songs;