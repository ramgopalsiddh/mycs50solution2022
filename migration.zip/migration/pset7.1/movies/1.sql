-- In 1.sql, write a SQL query to list the titles of all movies released in 2008

SELECT title FROM movies WHERE year = "2008";