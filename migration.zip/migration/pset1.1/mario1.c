#include<cs50.h>
#include<stdio.h>

int main (void)
{
    for (int i = 0; i < 30; i++)
    {
        for (int j = 0; j < 30; j++)
        {
            printf("#");
        }
        printf("\n");
    }
}